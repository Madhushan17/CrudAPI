package com.example.crudapi.service.impl;

import com.example.crudapi.dto.UserDto;
import com.example.crudapi.entity.User;
import com.example.crudapi.repos.UserRepo;
import com.example.crudapi.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepo userRepo;
    @Override
    public void addUser(User user) {
        userRepo.save(user);
    }
    @Override
    public List<User> getUsers() {
        return userRepo.findAll();
    }
    @Override
    public void updateUser(Integer id, User user) {
        userRepo.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid user id" + id));

        user.setId(id);

        userRepo.save(user);
    }
    @Override
    public void deleteUser(Integer id) {
        User user = userRepo
                .findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid User id" + id));

        userRepo.delete(user);
    }

    @Override
    public void updateName(Integer id, UserDto userDto) {
        User user = userRepo
                .findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Invalid User id" + id));

        user.setName(userDto.getName());
        userRepo.save(user);

    }
}
