package com.example.crudapi.service;

import com.example.crudapi.dto.UserDto;
import com.example.crudapi.entity.User;

import java.util.List;

public interface UserService {

    void addUser(User user);

    List<User> getUsers();

    void updateUser(Integer id, User user);

    void deleteUser(Integer id);

    void updateName(Integer id, UserDto userDto);
}
